# landmarks
2520 web dev project

started project on 2018-03-22

This project is a tourist application that highlights key landmarks based on
user input of city and country. It implements google APIs and localhost and
database

#meharder
