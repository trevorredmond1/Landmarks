//const save = require("/save.js");

/*-------------------------JSON OF COUNTRIES AND PLACES---------------------------------------------------*/

var favouritesList = [];

var Countries= {Canada: {center: {
                            coor: {lat: 51.4968, lng: -100.9281}
                            },
                         locations: [{
                             title:'Banff National Park',
                             address:'Banff National Park, Improvement District No. 9, AB T0L',
                             coor: {
                                 lat: 51.4968,
                                 lng: -115.9281},
                             picture: "pictures/banffpark.jpg"},{
                            title: 'CN Tower',
                            address: '301 Front St W, Toronto, ON M5V 2T6',
                             coor: {
                                    lat: 43.6426,
                                    lng: -79.3871},
                             picture: "pictures/cntower.jpg"},{
                               title: 'Stanley Park',
                               address: 'Vancouver, BC V6G 1Z4',
                             coor: {
                                    lat: 49.3017,
                                    lng: -123.1417},
                             picture: "pictures/stanleypark.jpg"}],
                         zoom: 4
                        },
                USA: {center: {
                            coor: {lat: 38.4968, lng: -100}
                            },
                         locations: [{
                           title: 'Central Park',
                           address: 'New York, NY, USA',
                             coor: {
                                 lat: 40.7829,
                                 lng: -73.9654},
                             picture: "pictures/centralpark.jpg"},{
                            title: 'Golden Gate Bridge',
                            address: 'Golden Gate Bridge, San Francisco, CA, USA',
                             coor: {
                                    lat: 37.8199,
                                    lng: -122.4783},
                             picture: "pictures/goldengatebridge.jpg"},{
                            title: 'Statue of Liberty',
                            address: 'New York, NY 10004, USA',
                             coor: {
                                    lat: 40.6892,
                                    lng: -74.0445},
                             picture: "pictures/statueofliberty.jpg"}],
                      zoom: 4
                        },
                Russia: {center: {
                            coor: {lat: 58.7520, lng: 33.6175}
                            },
                         locations: [{
                           title: 'Moscow Kremlin',
                           address: 'Moscow, Russia, 103073',
                             coor: {
                                 lat: 55.7520,
                                 lng: 37.6175},
                             picture: "pictures/moscowkremlin.jpg"},{
                            title: 'Red Square',
                            address: 'Moscow, Russia',
                             coor: {
                                    lat: 55.7539,
                                    lng: 37.6208},
                             picture: "pictures/redsquare.jpg"},{
                            title: 'Hermitage Museum',
                            address: 'Palace Square, 2, Sankt-Peterburg, Russia, 190000',
                             coor: {
                                    lat: 59.9398,
                                    lng: 30.3146},
                             picture: "pictures/hermitage.jpg"}],
                         zoom: 5
                        },
                China: {center: {
                            coor: {lat: 39.95, lng: 116.3}
                            },
                         locations: [{
                           title: 'Tiananmen Square',
                           address: 'Dongcheng, China',
                             coor: {
                                 lat:39.9055,
                                 lng: 116.3976},
                             picture: "pictures/tiananmensquare.jpg"},{
                            title: 'Forbidden City',
                            address: '4 Jingshan Front St, Dongcheng Qu, Beijing Shi, China, 100006',
                             coor: {
                                    lat: 39.9163,
                                    lng: 116.3972},
                             picture: "pictures/forbiddencity.jpg"},{
                            title: 'Summer Palace',
                            address: '19 Xinjiangongmen Rd, Haidian Qu, China, 100000',
                             coor: {
                                    lat: 40.0000,
                                    lng: 116.2755},
                             picture: "pictures/summerpalace.jpg"}],
                         zoom: 11
                        },
                Japan: {center: {
                            coor: {
                              lat:35.3394,
                              lng: 137.7292}
                            },
                         locations: [{
                           title: 'Kinkaku-ji',
                           address: '1 Kinkakujicho, Kita, Kyoto, Kyoto Prefecture 603-8361, Japan',
                             coor: {
                                 lat:35.0394,
                                 lng: 135.7292},
                             picture: "pictures/kinkakuji.jpg"},{
                            title: 'Senso-ji',
                            address: ' 2 Chome-3-1 Asakusa, Taitō, Tokyo 111-0032, Japan',
                             coor: {
                                    lat: 35.7148,
                                    lng: 139.7967},
                             picture: "pictures/sensoji.jpg"},{
                            title: 'Tokyo Tower',
                            address: '4 Chome-2-8 Shibakoen, Minato, Tokyo 105-0011, Japan',
                             coor: {
                                    lat: 35.6586,
                                    lng: 139.7454},
                             picture: "pictures/tokyotower.jpg"}],
                         zoom: 7
                        },
                Mexico: {center: {
                            coor: {lat:19.3394,
                                 lng: -93.7292}
                            },
                         locations: [{
                           title: 'Pyramid of the Magician',
                           address: 'Yucatán, Mexico',
                             coor: {
                                 lat:20.359444,
                                 lng: -89.771389},
                             picture: "pictures/uxmal.jpg"},{
                            title: 'Coba',
                            address: 'Km. 47, Carretera Federal Tulum 307, 77793 Cobá, Q.R., Mexico',
                             coor: {
                                    lat: 20.49472,
                                    lng: -87.736111},
                             picture: "pictures/coba.jpg"},{
                            title: 'Monte Alban',
                            address: 'Oaxaca, Mexico',
                             coor: {
                                    lat: 17.043889,
                                    lng: -96.767778},
                             picture: "pictures/montealban.jpg"}],
                         zoom: 6
                        },

            }



/*---------------------FUNCTIONS-------------------------------*/

/*---------------------Initializes a map-------------------------------------*/

 function initMap() {
        var marker =""
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 4,
          center: {lat: 51.4968, lng: -115.9281}
        });

 }

function addInfoWindow(marker, message) {

            var infoWindow = new google.maps.InfoWindow({
                content: message
            });

            google.maps.event.addListener(marker, 'click', function () {
                infoWindow.open(map, marker);
            });
        }

/*-------------------------------Changes the map markers-------------------------------*/

function changeMap(center, locations, zoom) {
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: zoom,
          center: center
        });

        var locations = locations;

        for (var i =0; i < locations.length; i++){
         marker = new google.maps.Marker({
            position: locations[i].coor,
            animation: google.maps.Animation.DROP,
            map: map
          });

          addInfoWindow(marker,"<p><b>" + locations[i].title + "</b></p><p>"+locations[i].address+"</p>")
        }
      }

/*------------------------------------Changes the images on the right side---------------------------*/

function changeImage(div, image, dtitle){
  if (div == 0){
    document.getElementById('firstcountry').style.backgroundImage = "url(" + image + ")";
    document.getElementById('title1').innerHTML= dtitle
  }
  else if (div == 1){
    document.getElementById('secondcountry').style.backgroundImage = "url(" + image + ")";
    document.getElementById('title2').innerHTML = dtitle
  }
  else if (div == 2){
    document.getElementById('thirdcountry').style.backgroundImage = "url(" + image + ")";
    document.getElementById('title3').innerHTML= dtitle
  }

}

/*-----------------------------COUNTRY BUTTONS-----------------------------------*/

document.getElementById('Canada').addEventListener("click", function(){
    changeMap(Countries.Canada.center.coor,Countries.Canada.locations,Countries.Canada.zoom)
    for (var i = 0; i < 3; i++){
        changeImage(i, Countries.Canada.locations[i].picture, Countries.Canada.locations[i].title)
    }
});

document.getElementById('USA').addEventListener("click", function(){
    changeMap(Countries.USA.center.coor,Countries.USA.locations,Countries.USA.zoom)
    for (var i = 0; i < 3; i++){
        changeImage(i, Countries.USA.locations[i].picture, Countries.USA.locations[i].title)
    }
});

document.getElementById('Russia').addEventListener("click", function(){
    changeMap(Countries.Russia.center.coor,Countries.Russia.locations, Countries.Russia.zoom)
    for (var i = 0; i < 3; i++){
        changeImage(i, Countries.Russia.locations[i].picture, Countries.Russia.locations[i].title)
    }
});

document.getElementById('China').addEventListener("click", function(){
    changeMap(Countries.China.center.coor,Countries.China.locations, Countries.China.zoom)
    for (var i = 0; i < 3; i++){
        changeImage(i, Countries.China.locations[i].picture, Countries.China.locations[i].title)
    }
});

document.getElementById('Japan').addEventListener("click", function(){
    changeMap(Countries.Japan.center.coor,Countries.Japan.locations, Countries.Japan.zoom)
    for (var i = 0; i < 3; i++){
        changeImage(i, Countries.Japan.locations[i].picture,  Countries.Japan.locations[i].title)
    }
});

document.getElementById('Mexico').addEventListener("click", function(){
    changeMap(Countries.Mexico.center.coor,Countries.Mexico.locations, Countries.Mexico.zoom)
    for (var i = 0; i < 3; i++){
        changeImage(i, Countries.Mexico.locations[i].picture, Countries.Mexico.locations[i].title)
    }
});

/*----------------------------------makes info for clicking on picture-------------*/

var showfirstcountry = document.getElementById("firstcountryinfo")
        document.getElementById("firstcountry").addEventListener("mouseover", function() {
            showfirstcountry.style.display="block";
        });
        showfirstcountry.addEventListener("mouseleave", function() {
            showfirstcountry.style.display="none";
        });

var showsecondcountry = document.getElementById("secondcountryinfo")
        document.getElementById('secondcountry').addEventListener("mouseover", function() {
            showsecondcountry.style.display="block";
        });
        showsecondcountry.addEventListener("mouseleave", function() {
            showsecondcountry.style.display="none";
        });

var showthirdcountry = document.getElementById("thirdcountryinfo")
       document.getElementById('thirdcountry').addEventListener("mouseover", function() {
            showthirdcountry.style.display="block";
        });
        showthirdcountry.addEventListener("mouseleave", function() {
            showthirdcountry.style.display="none";
        });

/*-----------------------------------------get email info---------------------------*/

document.getElementById("save1").addEventListener("click", function(){
  var entry = document.getElementById("title1").innerHTML;
  favouritesList.push[entry];
});

document.getElementById("save2").addEventListener("click", function(){
  var entry = document.getElementById("title2").innerHTML;
  favouritesList.push[entry];
});

document.getElementById("save3").addEventListener("click", function(){
  var entry = document.getElementById("title3").innerHTML;
  favouritesList.push[entry];
});

document.getElementById('savedshow').addEventListener("click", function(){
  document.getElementById('displaysaved').innerHTML =""
  for (var n in favouritesList){
    document.getElementById('displaysaved').innerHTML += "" + favouritesList[n]+"<br>"
}
})
